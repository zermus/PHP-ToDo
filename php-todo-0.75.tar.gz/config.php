<?php
// Database configuration
$host = 'localhost'; // or your host
$dbname = 'tododbname';
$db_username = 'tododbuser';
$db_password = 'yourpassword';

// Base URL of the application, including the path to the app
$base_url = 'https://yourwebsite.com/todo/';  // Adjust this to your actual domain and application path

// Email configuration
$from_email = 'todo@yourwebsite.com'; // Configurable sender email address
?>
